python3 helperService.py $1 $2
