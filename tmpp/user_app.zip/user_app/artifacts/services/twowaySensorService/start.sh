python3 twowaySensorService.py $1 $2
