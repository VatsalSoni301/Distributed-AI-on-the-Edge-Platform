python3 notificationService.py $1 $2
