python3 distanceAlarmService.py $1 $2
